// create express object from express module
let express = require('express');
// create body parser object from body-parser package
let bodyParser = require('body-parser');

// call express constructor to create express application object
let app = express();
app.use(bodyParser.urlencoded({ extended: false }));

// create a handler (using an arrow function) for the HTTP GET request
// use the __dirname global value to create fully qualified url
app.get('/', (request, response) => response.sendFile(__dirname + "/index.html"));

// create a handler (using an arrow function) for the HTTP POST request
app.post('/api/data', (request, response) => {
    let postBody = request.body;

    if (postBody.customerID === "1") {
        postBody.firstName = "Sherlock";
        postBody.lastName = "Holmes";
        postBody.address = "221 B Baker Street";
        postBody.city = "London";
        postBody.province = "Ontario";
        postBody.postalCode = "N1M O2P";
        response.send(postBody);
    }
    else {
        postBody.firstName = "";
        postBody.lastName = "";
        postBody.address = "";
        postBody.city = "";
        postBody.province = "";
        postBody.postalCode = "";
        response.send(postBody);
    }
});

app.get('/', function (req, res) {
    // create a mssql SQL object from mssql module (package)
    var sql = require("mssql");

    // create configuration object literal for connection string
    // must use SQL authentication
    // note the the \\ in the SQL server name
    var config = {
        user: 'sa',
        password: "password",
        server: 'NELSONKHIEV0028\\SQLEXPRESS',
        database: 'Store'
    };

    // connect to the store database
    sql.connect(config, function (err) {


        if (err) {
            console.log(err);
        }

        // create some data values
        // note the addition of an int age value
        // ... this will need to be added to the
        // customers table
        let firstName = document.getElementById("txtFirstName");
        let lastName = document.getElementById("txtLastName");
        let address = document.getElementById("txtAddress");
        let city = document.getElementById("txtCity");
        let province = document.getElementById("txtProvince");
        let postal = document.getElementById("txtPostalCode");

        // create a SQL query string with place holder values
        let queryString = "INSERT INTO Customers (FirstName, LastName, Address, City, Province, PostalCode) VALUES (@FirstName, @LastName, @Address, @City, @Province, @PostalCode)";

        // create Request object
        let request = new sql.Request();

        // input the parameter values and associated SQL Server types
        request.input("FirstName", sql.VarChar(50), firstName)
            .input("LastName", sql.VarChar(50), lastName)
            .input("Address", sql.VarChar(50), address)
            .input("City", sql.VarChar(50), city)
            .input("Province", sql.VarChar(25), province)
            .input("PostalCode", sql.VarChar(10), postal)
  
            // chain the query
            .query(queryString, function (err, recordset) {
                if (err) {
                    console.log(err);
                }

                // output recordset as a response for debugging purposes
                console.log(recordset);

                // create the SQL to get the last "identity" field value
                queryString = "SELECT @@IDENTITY AS 'identity'";
                request.query(queryString, function (err, returnVal) {
                    if (err) {
                        console.log(err);
                    }
                    // extract the "CusID" assigned by SQL Server for the last INSERT
                    let identValue = returnVal.recordset[0].identity;
                    console.log("New CusID = " + identValue);
                });
            });
    });
});

// create the web server running on hard coded port 3000
let server = app.listen(3000, function () {
    console.log('Server is running.');
});