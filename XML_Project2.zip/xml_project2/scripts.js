/*
    File:           schools.js
    Author:         N. Khiev
    Date:           Mar 29, 2020
*/

function loadXMLDoc(filename) {
    if (window.ActiveXObject) {
        xhttp = new ActiveXObject("Msxml2.XMLHTTP");
    }
    else {
        xhttp = new XMLHttpRequest();
    }
    xhttp.open("GET", filename, false);

    try {
        xhttp.responseType = "msxml-document";
    }
    catch (err) { }
    xhttp.send("");
    return xhttp.responseXML;
}

function renderTable() {
    if (window.ActiveXObject || xhttp.responseType == "msxml-document") {
        var template = new ActiveXObject("Msxml2.XslTemplate.6.0");
        template.stylesheet = xslt;

        var proc = template.createProcessor();
        proc.input = xml;

        proc.transform();
        document.getElementById("output").innerHTML = proc.output;
    }
    else if (typeof XSLTProcessor !== 'undefined') {
        var xsltProcessor = new XSLTProcessor();
        xsltProcessor.importStylesheet(xslt);

        var resultDocument = xsltProcessor.transformToFragment(xml, document);
        document.getElementById("output").innerHTML = "";
        document.getElementById("output").appendChild(resultDocument);
    }
}

function search() {
    loadData('schools.xml', 'search.xslt');
    var name = document.getElementById("name").value;

    if (window.ActiveXObject || xhttp.responseType == "msxml-document") {
        var template = new ActiveXObject("Msxml2.XslTemplate.6.0");
        template.stylesheet = xslt;

        var proc = template.createProcessor();
        proc.input = xml;
        proc.addParameter("name", name);

        proc.transform();
        document.getElementById("output").innerHTML = proc.output;
    }
    else if (typeof XSLTProcessor !== 'undefined') {
        var xsltProcessor = new XSLTProcessor();
        xsltProcessor.importStylesheet(xslt);

        xsltProcessor.setParameter(null, "name", name);

        var resultDocument = xsltProcessor.transformToFragment(xml, document);
        document.getElementById("output").innerHTML = "";
        document.getElementById("output").appendChild(resultDocument);
    }
}

function loadData(x, y) {
    x.toString();
    y.toString();

    xml = loadXMLDoc(x);
    xslt = loadXMLDoc(y);
}


function select() {
    document.getElementById("name").value = "";

    if (document.getElementById("dropdown").value === "Pre-School") {
        loadData("schools.xml", "pre-school.xslt");
        renderTable();
    } else if (document.getElementById("dropdown").value === "Elementary") {
        loadData("schools.xml", "elementary.xslt");
        renderTable();
    } else if (document.getElementById("dropdown").value === "Secondary") {
        loadData("schools.xml", "secondary.xslt");
        renderTable();
    } else if (document.getElementById("dropdown").value === "Post-Secondary") {
        loadData("schools.xml", "post-secondary.xslt");
        renderTable();
    } else if (document.getElementById("dropdown").value === "Adult Education") {
        loadData("schools.xml", "adult-education.xslt");
        renderTable();
    } else {
        loadData('schools.xml', 'schools.xslt');
        renderTable();
    }
}