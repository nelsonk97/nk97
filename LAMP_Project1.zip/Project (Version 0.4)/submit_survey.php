<html>
    <head>
        <meta charset="utf-8">
        <title>Project 1 - Survey</title>
    </head>
    <style>
    * {
        font-family: 'Helvetica';
    }

    h2 {
        font-weight: 200;
    }
    </style>
    <body>
        <h1>Thank you.</h1>
        <h2>Your survey has been successfully submitted.</h2>
<?php
require_once("./projectdb.php");
$dbc = connectDB();
?>

<?php

?>

</body>
</html>