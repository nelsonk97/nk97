<html>
    <head>
        <meta charset="utf-8">
        <title>Project 1 - Survey</title>
    </head>
    <style>
    * {
        font-family: 'Helvetica';
    }
    </style>
    <body>
        <h1>Recent Purchase - Page 3/3</h1>
        <div>
<?php
require_once("./projectdb.php");
$dbc = connectDB();
?>

<?php
form_3();
?>

<?php function form_3($buttons = "", $check = array(), $recommend = ""){ ?>
	<div id="table3">
    <h3>How happy are you with this device on a scale from 1 (Not satisfied) to 5 (Very satisfied)?</h3>
	<form method="POST" id="info_3" action="./page1_survey.php">
		<input type="radio" value="1" name="buttons[]" value="1" <?php if ($buttons == "1") { echo 'checked';} ?>>1</input><br>
		<input type="radio" value="2" name="buttons[]" value="2" <?php if ($buttons == "2") { echo 'checked';} ?>>2</input><br>
		<input type="radio" value="3" name="buttons[]" value="3" <?php if ($buttons == "3") { echo 'checked';} ?>>3</input><br>
		<input type="radio" value="4" name="buttons[]" value="4" <?php if ($buttons == "4") { echo 'checked';} ?>>4</input><br>
		<input type="radio" value="5" name="buttons[]" value="5" <?php if ($buttons == "5") { echo 'checked';} ?>>5</input><br>
    	<h3>Would you recommend the purchase of this device to a friend?</h3>
        <select type="select" id="recommend" name="recommend" value="<?php echo $recommend; ?>">
            <option value="" selected disabled hidden>Choose here</option>
            <option name="yes" value="yes" <?php if(isset($recommend[1])) echo 'checked'; ?>>Yes</option>
            <option name="maybe" value="maybe" <?php if(isset($recommend[2])) echo 'checked'; ?>>Maybe</option>
            <option name="no" value="no" <?php if(isset($recommend[3])) echo 'checked'; ?>>No</option>
        </select>
    </form>
</div>
<?php } ?>

<br>

<button onclick="location.href='./page2_survey.php'">Back</button>
<button onclick="location.href='./submit_survey.php'">Submit</button>

</body>
</html>