<html>
    <head>
        <meta charset="utf-8">
        <title>Project 1 - Survey</title>
    </head>
    <style>
    * {
        font-family: 'Helvetica';
    }
    </style>
    <body>
        <h1>Recent Purchase - Page 1/3</h1>
        <div>
<?php
require_once("./projectdb.php");
$dbc = connectDB();
?>

<?php
form_1();
?>

<?php function form_1($name = "", $age = "", $student = ""){ ?>
    <div id="table1">
    <form method="POST" id="info_1" action="./page1_survey.php">
        Full Name: <input type="text" size="20" maxlength="25" id ="name" name="name" value="<?php echo $name; ?>"></input><br>
        Age: <input type="text" size="20" maxlength="25" id ="age" name="age" value="<?php echo $age; ?>"><br>
        Student: 
        <select type="select" id ="student" name="student" value="<?php echo $student; ?>">
            <option value="" selected disabled hidden>Choose here</option>
            <option>No</option>
            <option>Yes</option>
        </select>
    </form>
    </div><br>
<?php } ?>

<br>

<button onclick="location.href='./index.php'">Back</button>
<button onclick="location.href='./page2_survey.php'">Submit</button>

</body>
</html>
