<html>
    <head>
        <meta charset="utf-8">
        <title>Project 1 - Survey</title>
    </head>
    <style>
    * {
        font-family: 'Helvetica';
    }
    </style>
    <body>
        <h1>Welcome!</h1>
        <div>
<?php
require_once("./projectdb.php");
$dbc = connectDB();
?>

<?php

?>
	</div>
    <div id="instructions">
        <p>To begin the survey regarding your recent purchase, click on the <b>Start Survey</b> button.</p>
        <p>Read the questions carefully and be sure to answer accordingly to restrictions!</p>
    </div>
    <button id="startBtn" onclick="location.href='./page1_survey.php'">Start Survey</button>
</body>
</html>