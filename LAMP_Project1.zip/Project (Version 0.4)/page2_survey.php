<html>
    <head>
        <meta charset="utf-8">
        <title>Project 1 - Survey</title>
    </head>
    <style>
    * {
        font-family: 'Helvetica';
    }
    </style>
    <body>
        <h1>Recent Purchase - Page 2/3</h1>
        <div>
<?php
require_once("./projectdb.php");
$dbc = connectDB();
?>

<?php
form_2();
?>

<?php function form_2($buttons = "", $check = array()){ ?>
	<div id="table2">
    	<h3>How did you complete your purchase?</h3>
		<form method="POST" id="info_2" action="./page1_survey.php">
			<input type="radio" value="online" name="buttons[]" value="online" <?php if ($buttons == "Online") { echo 'checked';} ?>>Online</input><br>
			<input type="radio" value="byPhone" name="buttons[]" value="byPhone" <?php if ($buttons == "ByPhone") { echo 'checked';} ?>>By Phone</input><br>
			<input type="radio" value="mobileApp" name="buttons[]" value="mobileApp" <?php if ($buttons == "MobileApp") { echo 'checked';} ?>>Mobile App</input><br>
			<input type="radio" value="inStore" name="buttons[]" value="inStore" <?php if ($buttons == "InStore") { echo 'checked';} ?>>In Store</input><br>
			<input type="radio" value="byMail" name="buttons[]" value=byMail" <?php if ($buttons == "ByMail") { echo 'checked';} ?>>By Mail</input><br>
			<h3>How did you complete your purchase?</h3>
			<input type="checkbox" name="homePhone" value="homePhone" <?php if(isset($check[1])) echo 'checked'; ?>>Home Phone</input><br>
			<input type="checkbox" name="MobilePhone" value="mobilePhone" <?php if(isset($check[2])) echo 'checked'; ?>>Mobile Phone</input><br>
			<input type="checkbox" name="smartTV" value="smartTV" <?php if(isset($check[3])) echo 'checked'; ?>>Smart TV</input><br>
			<input type="checkbox" name="laptop" value="laptop" <?php if(isset($check[4])) echo 'checked'; ?>>Laptop</input><br>
			<input type="checkbox" name="desktopComputer" value="desktopComputer" <?php if(isset($check[5])) echo 'checked'; ?>>Desktop Computer</input><br>
			<input type="checkbox" name="tablet" value="tablet" <?php if(isset($check[6])) echo 'checked'; ?>>Tablet</input><br>
			<input type="checkbox" name="homeTheatre" value="homeTheatre" <?php if(isset($check[7])) echo 'checked'; ?>>Home Theatre</input><br>
			<input type="checkbox" name="mp3Player" value="mp3Player" <?php if(isset($check[8])) echo 'checked'; ?>>MP3 Player</input><br>
    	</form>
	</div>
<?php } ?>

<br>

<button onclick="location.href='./page1_survey.php'">Back</button>
<button onclick="location.href='./page3_survey.php'">Submit</button>

</body>
</html>