/*
    File:           airport.js
    Author:         N. Khiev
    Date:           Jan 22, 2020
*/
var d = new Date();
var date_string =
    d.getFullYear().toString().substring(2) +
    (d.getMonth() < 9 ? "0" : "") + (d.getMonth() + 1) +
    (d.getDate() < 10 ? "0" : "") + d.getDate();

function loadXMLDoc() {
    // Create XMLHttpRequest object
    var xmlHttp = new XMLHttpRequest();

    // Once XML document is loaded, process the data
    xmlHttp.onreadystatechange = function () {
        document.getElementById("table-header").innerHTML = "";

        if (this.readyState === 4 && this.status === 200) {
            var selection = document.getElementById("selection").value;
            if (selection === "arrivals") {
                displayArrivals(this);
                document.getElementById("table-header").innerHTML = "<h3>Arrivals</h3>";
            }
            else if (selection === "departures") {
                displayDepartures(this);
                document.getElementById("table-header").innerHTML = "<h3>Departures</h3>";
            }
        }
    }
    
    // Send a request for the XML data
    xmlHttp.open("GET", "flight.xml", true);
    xmlHttp.send();
}

function displayArrivals(xml) {
    var xmlDoc = xml.responseXML;

    var name = xmlDoc.documentElement.attributes.getNamedItem("name");
    var abbreviation = xmlDoc.documentElement.attributes.getNamedItem("abbreviation");

    document.getElementById("header").innerHTML = "<h1>" + name.value + " (" + abbreviation.value + ")</h1>";

    var table = "<tr><th>Airline</th><th>Number</th><th>Arrival From</th><th>Scheduled Time</th><th>Actual Time</th><th>Status</th></tr>";
    var x = xmlDoc.getElementsByTagName("flight");

    for (var i = 0; i < x.length; i++) {

        var attrs = x[i].attributes;

        if (attrs.getNamedItem("type").value === "arrival") {
            table += "<tr><td>" +
                x[i].getElementsByTagName("airline")[0].childNodes[0].nodeValue +
                "</td><td>" +
                x[i].getElementsByTagName("flight-number")[0].childNodes[0].nodeValue +
                "</td><td>" +
                x[i].getElementsByTagName("arrival-from")[0].childNodes[0].nodeValue +
                "</td><td>" +
                x[i].getElementsByTagName("scheduled-time")[0].childNodes[0].nodeValue +
                "</td><td>" +
                x[i].getElementsByTagName("actual-time")[0].childNodes[0].nodeValue +
                "</td><td>" +
                x[i].getElementsByTagName("status")[0].childNodes[0].nodeValue +
                "</td></tr>";
        }
    }
    document.getElementById("output").innerHTML = table;
}

function displayDepartures(xml) {
    var xmlDoc = xml.responseXML;

    var name = xmlDoc.documentElement.attributes.getNamedItem("name");
    var abbreviation = xmlDoc.documentElement.attributes.getNamedItem("abbreviation");

    document.getElementById("header").innerHTML = "<h1>" + name.value + " (" + abbreviation.value + ")</h1>";

    var table = "<tr><th>Airline</th><th>Number</th><th>Departure To</th><th>Scheduled Time</th><th>Actual Time</th><th>Status</th></tr>";
    var x = xmlDoc.getElementsByTagName("flight");

    for (var i = 0; i < x.length; i++) {

        var attrs = x[i].attributes;

        if (attrs.getNamedItem("type").value === "departure") {
            table += "<tr><td>" +
                x[i].getElementsByTagName("airline")[0].childNodes[0].nodeValue +
                "</td><td>" +
                x[i].getElementsByTagName("flight-number")[0].childNodes[0].nodeValue +
                "</td><td>" +
                x[i].getElementsByTagName("departing-to")[0].childNodes[0].nodeValue +
                "</td><td>" +
                x[i].getElementsByTagName("scheduled-time")[0].childNodes[0].nodeValue +
                "</td><td>" +
                x[i].getElementsByTagName("actual-time")[0].childNodes[0].nodeValue +
                "</td><td>" +
                x[i].getElementsByTagName("status")[0].childNodes[0].nodeValue +
                "</td></tr>";
        }
    }
    document.getElementById("output").innerHTML = table;
}