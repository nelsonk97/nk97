<!-- Written by Nelson Khiev, Parin Parikh and Justin Lott
  shows details of selected contact
  File: saveEdits.php
  Purpose: Save the editted contact to DB -->
<?php
  function saveEdits($db_conn) {
    $data = [];
    $qry = "UPDATE contact SET ct_type = ?";
    $data[] = $_POST['editSelType'];
    $qry .= ", ct_first_name = ?";
    $data[] = $_POST['txtFirst'];
    $qry .= ", ct_last_name = ?";
    $data[] = $_POST['txtLast'];
    $qry .= ", ct_disp_name = ? WHERE ct_id = ".$_SESSION['selContact'];
    $data[] = $_POST['txtDisp'];

    $stmt = $db_conn->prepare($qry);
    if (!$stmt) {
      echo "<p>Error in contact prepare: ".$dbc->errorCode()."</p>\n<p>Message ".implode($dbc->errorInfo())."</p>\n";
      exit(1);
    }
    $stat = $stmt->execute($data);
    if (!$stat) {
      echo "Error in contact execute: ".$stmt->errorCode()."\n ".implode($stmt->errorInfo());
      exit(1);
    }
    $db_conn = NULL;
    //open connection to db for address
    $db_conn = connectDB();
    $data = [];
    $qry = "UPDATE contact_address SET ad_type = ?";
    $data[] = $_POST['editAdType'];
    $qry .= ", ad_line_1 = ?";
    $data[] = $_POST['txtAd1'];
    $qry .= ", ad_line_2 = ?";
    $data[] = $_POST['txtAd2'];
    $qry .= ", ad_line_3 = ?";
    $data[] = $_POST['txtAd3'];
    $qry .= ", ad_city = ?";
    $data[] = $_POST['txtCity'];
    $qry .= ", ad_province = ?";
    $data[] = $_POST['txtProv'];
    $qry .= ", ad_post_code = ?";
    $data[] = $_POST['txtPostal'];
    $qry .= ", ad_country = ? WHERE ad_ct_id = ".$_SESSION['selContact'];
    $data[] = $_POST['txtCountry'];

    $stmt = $db_conn->prepare($qry);
    if (!$stmt) {
      echo "<p>Error in ADDRESS prepare: ".$dbc->errorCode()."</p>\n<p>Message ".implode($dbc->errorInfo())."</p>\n";
      exit(1);
    }
    $stat = $stmt->execute($data);
    if (!$stat) {
      echo "Error in ADDRESS execute: ".$stmt->errorCode()."\n ".implode($stmt->errorInfo());
      exit(1);
    }
    $db_conn = NULL;
    //open connection to db for PHONE
    $db_conn = connectDB();
    $data = [];
    $qry = "UPDATE contact_phone SET ph_type = ?";
    $data[] = $_POST['editPhType'];
    $qry .= ", ph_number = ? WHERE ph_ct_id = ".$_SESSION['selContact'];
    $data[] = $_POST['txtPhNum'];

    $stmt = $db_conn->prepare($qry);
    if (!$stmt) {
      echo "<p>Error in PHONE prepare: ".$dbc->errorCode()."</p>\n<p>Message ".implode($dbc->errorInfo())."</p>\n";
      exit(1);
    }
    $stat = $stmt->execute($data);
    if (!$stat) {
      echo "Error in PHONE execute: ".$stmt->errorCode()."\n ".implode($stmt->errorInfo());
      exit(1);
    }
    $db_conn = NULL;
    //open connection to db for EMAIL
    $db_conn = connectDB();
    $data = [];
    $qry = "UPDATE contact_email SET em_type = ?";
    $data[] = $_POST['editEmType'];
    $qry .= ", em_email = ? WHERE em_ct_id = ".$_SESSION['selContact'];
    $data[] = $_POST['txtEmail'];
    
    $stmt = $db_conn->prepare($qry);
    if (!$stmt) {
      echo "<p>Error in EMAIL prepare: ".$dbc->errorCode()."</p>\n<p>Message ".implode($dbc->errorInfo())."</p>\n";
      exit(1);
    }
    $stat = $stmt->execute($data);
    if (!$stat) {
      echo "Error in EMAIL execute: ".$stmt->errorCode()."\n ".implode($stmt->errorInfo());
      exit(1);
    }
    $db_conn = NULL;
    //WEB
    $db_conn = connectDB();
    $data = [];
    $qry = "UPDATE contact_web SET we_type = ?";
    $data[] = $_POST['editWebType'];
    $qry .= ", we_url = ? WHERE we_ct_id = ".$_SESSION['selContact'];
    $data[] = $_POST['txtWebURL'];

    $stmt = $db_conn->prepare($qry);
    if (!$stmt) {
      echo "<p>Error in WEB prepare: ".$dbc->errorCode()."</p>\n<p>Message ".implode($dbc->errorInfo())."</p>\n";
      exit(1);
    }
    $stat = $stmt->execute($data);
    if (!$stat) {
      echo "Error in WEB execute: ".$stmt->errorCode()."\n ".implode($stmt->errorInfo());
      exit(1);
    }
    $db_conn = NULL;
    //NOTE
    $db_conn = connectDB();
    $data = [];
    $qry = "UPDATE contact_note SET no_note = ? WHERE no_ct_id = ".$_SESSION['selContact'];
    $data[] = $_POST['txtEditNote'];

    $stmt = $db_conn->prepare($qry);
    if (!$stmt) {
      echo "<p>Error in NOTE prepare: ".$dbc->errorCode()."</p>\n<p>Message ".implode($dbc->errorInfo())."</p>\n";
      exit(1);
    }
    $stat = $stmt->execute($data);
    if (!$stat) {
      echo "Error in NOTE execute: ".$stmt->errorCode()."\n ".implode($stmt->errorInfo());
      exit(1);
    }
    $db_conn = NULL;
  }
?>