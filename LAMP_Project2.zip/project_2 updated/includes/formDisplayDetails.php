<?php /* formDisplayDetails.php Written by Nelson Khiev, Parin Parikh and Justin Lott
shows details of selected contact */
function formDisplayDetails($db_conn) {
    $stmt = $db_conn->prepare("select * from contact where ct_id =".$_SESSION['list_select']);
    if (!$stmt){
		echo "<p>Could not get data from database</p>\n";
	} else {
		$status = $stmt->execute();
		if(!$status){
		echo "<p>Could not get data from database</p>\n";
		} else {
			if ($stmt->rowCount() > 0){
				echo "<table border=\"1\">\n";
					while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
?>
<form method='POST'>
	<tr><td>Contact Type</td><td><?php echo $row['ct_type']; ?></td></tr>
	<tr><td>Display/Business Name</td><td><?php echo $row['ct_disp_name']; ?></td></tr>
	<tr><td>First Name</td><td><?php echo $row['ct_first_name']; ?></td></tr>
    <tr><td>Last Name</td><td><?php echo $row['ct_last_name']; ?></td></tr>
<?php
        }
      }
    }
  }
    $stmt = $db_conn->prepare("select * from contact_address where ad_ct_id =".$_SESSION['list_select']);
    if (!$stmt){
        echo "<p>Could not get data from database</p>\n";
    } else {
        $status = $stmt->execute();
        if(!$status){
        echo "<p>Could not get data from database</p>\n";
        } else {
            if ($stmt->rowCount() > 0){
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
?>
    <tr><td>Address Type</td><td><?php echo$row['ad_type']; ?></td></tr>
    <tr><td>Address Line 1</td><td><?php echo $row['ad_line_1']; ?></td></tr>
    <tr><td>Address Line 2</td><td><?php echo $row['ad_line_2']; ?></td></tr>
    <tr><td>Address Line 3</td><td><?php echo $row['ad_line_3']; ?></td></tr>
    <tr><td>City</td><td><?php echo $row['ad_city']; ?></td></tr>
    <tr><td>Province</td><td><?php echo $row['ad_province']; ?></td></tr>
    <tr><td>Post Code</td><td><?php echo $row['ad_post_code']; ?></td></tr>
    <tr><td>Country</td><td><?php echo $row['ad_country']; ?></td></tr>
<?php
      }
    }
  }
 }
 $stmt = $db_conn->prepare("select * from contact_email where em_id =".$_SESSION['list_select']);
    if (!$stmt){
        echo "<p>Could not get data from database</p>\n";
    } else {
        $status = $stmt->execute();
        if(!$status){
        echo "<p>Could not get data from database</p>\n";
        } else {
            if ($stmt->rowCount() > 0){
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
?>
<tr><td>Email Type:</label></td><td><?php echo$row['em_type']; ?></td></tr>
<tr><td>Email Address:</label></td><td><?php echo$row['em_email']; ?></td></tr>
<?php
      }
    }
  }
}
$stmt = $db_conn->prepare("select * from contact_phone where ph_ct_id =".$_SESSION['list_select']);
    if (!$stmt){
        echo "<p>Could not get data from database</p>\n";
    } else {
        $status = $stmt->execute();
        if(!$status){
        echo "<p>Could not get data from database</p>\n";
        } else {
            if ($stmt->rowCount() > 0){
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
?>
<tr><td>Phone Type:</label></td><td><?php echo$row['ph_type']; ?></td></tr>
<tr><td>Phone Number</label></td><td><?php echo$row['ph_number']; ?></td></tr>
<?php
      }
    }
  }
}
$stmt = $db_conn->prepare("select * from contact_note where no_ct_id =".$_SESSION['list_select']);
    if (!$stmt){
        echo "<p>Could not get data from database</p>\n";
    } else {
        $status = $stmt->execute();
        if(!$status){
        echo "<p>Could not get data from database</p>\n";
        } else {
            if ($stmt->rowCount() > 0){
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
?>
<tr><td>NOTE:</label></td><td><?php echo$row['no_note']; ?></td></tr>
<?php
      }
    }
  }
}
$stmt = $db_conn->prepare("select * from contact_web where we_ct_id =".$_SESSION['list_select']);
    if (!$stmt){
        echo "<p>Could not get data from database</p>\n";
    } else {
        $status = $stmt->execute();
        if(!$status){
        echo "<p>Could not get data from database</p>\n";
        } else {
            if ($stmt->rowCount() > 0){
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
?>
<tr><td>Web Site Type:</label></td><td><?php echo$row['we_type']; ?></td></tr>
<tr><td>Web Site URL:</label></td><td><?php echo$row['we_url']; ?></td></tr>
<?php
      }
    }
  }
}
?>
</table>
<input type='submit' name='btnBack' id='btnBack' value='Go Back' />
</form>
<?php
}

?>
