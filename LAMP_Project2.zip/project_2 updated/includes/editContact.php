<!-- editContact.php Written by Nelson Khiev, Parin Parikh and Justin Lott
  Directs to page with contacts and allows fields to be edited -->
<?php function editContact($ct_id) {  
  //open connection to the database
  $db_conn = connectDB();
  $qry = "SELECT ct_type, ct_first_name, ct_last_name, ct_disp_name FROM contact WHERE ct_id = '$ct_id'";
  $stmt = $db_conn->prepare($qry);
  if (!$stmt) {
    echo "<p>Error in EDIT Contact Table prepare: ".$dbc->errorCode()."</p>\n<p>Message ".implode($dbc->errorInfo())."</p>\n";
		exit(1);
  }
  $status = $stmt->execute();
  if ($status) {
    if ($stmt->rowCount() > 0) {
      $row = $stmt->fetch(PDO::FETCH_ASSOC);
      //variables for contact type and name
      $type = $row["ct_type"];
      $fName = $row["ct_first_name"];
      $lName = $row["ct_last_name"];
      $dName = $row['ct_disp_name'];
      ?>
<form method="POST">
  <h2>Edit Contact</h2>
  <hr />
  <label for='selType'>Contact Type:</label>
  <select id='selType' name='editSelType'>
    <?php if((strlen($type) ==0) ){ ?>
    <option selected="selected" value="Choice">Select type</option>
    <?php }
    else { ?>
    <option value="Choice">Select type</option>
    <?php }
	  if ($type == "Family"){ ?>
    <option selected="selected" value="Family">Family</option>
    <?php }
    else { ?>
    <option value="Family">Family</option>
    <?php }
	  if ($type == "Friend"){ ?>
    <option selected="selected" value="Friend">Friend</option>
    <?php }
    else { ?>
    <option value="Friend">Friend</option>
    <?php }
	  if ($type == "Business"){ ?>
    <option selected="selected" value="Business">Business</option>
    <?php }
    else { ?>
    <option value="Business">Business</option>
    <?php }
	  if ($type == "Other"){ ?>
    <option selected="selected" value="Other">Other</option>
    <?php }
    else { ?>
    <option value="Other">Other</option>
    <?php } ?>
  </select>
  <label for='txtFirst'>First Name:</label>
  <input type="text" id="txtFirst" name='txtFirst' value="<?php echo $fName; ?>">
  <br />
  <label for='txtLast'>Last Name:</label>
  <input type="text" id="txtLast" name='txtLast' value="<?php echo $lName; ?>">
  <br />
  <label for='txtDisp'>Display Name:</label>
  <input type="text" id="txtDisp" name='txtDisp' value="<?php echo $dName; ?>">
  <br />
  <?php }
  }
  else {
    echo "<p>Error in EDIT Contact table execute ".$stmt->errorCode()."</p>\n<p>Message ".implode($stmt->errorInfo())."</p>\n";
    exit(1);
  }
  $db_conn = NULL;
  //open connection to the database
  $db_conn = connectDB();
  //get address info from database
  $qry = "SELECT ad_type, ad_line_1, ad_line_2, ad_line_3, ad_city, ad_province, ad_post_code, ad_country FROM contact_address WHERE ad_ct_id = '$ct_id'";
  $stmt = $db_conn->prepare($qry);
  if (!$stmt) {
    echo "<p>Error in EDIT Address table prepare: ".$dbc->errorCode()."</p>\n<p>Message ".implode($dbc->errorInfo())."</p>\n";
    exit(1);
  }
  $status = $stmt->execute();
  if ($status) {
    if ($stmt->rowCount() > 0) {
      $row = $stmt->fetch(PDO::FETCH_ASSOC);
      //variables for data from db
      $type = $row['ad_type'];
      $l1 = $row['ad_line_1'];
      $l2 = $row['ad_line_2'];
      $l3 = $row['ad_line_3'];
      $city = $row['ad_city'];
      $prov = $row['ad_province'];
      $pc = $row['ad_post_code'];
      $cou = $row['ad_country'];
      ?>
  <label for='selAdType'>Address Type:</label>
  <select id='selAdType' name='editAdType'>
    <?php if((strlen($type) ==0) ){ ?>
    <option selected="selected" value="Choice">Select type</option>
    <?php }
    else { ?>
    <option value="Choice">Select type</option>
    <?php }
	  if ($type == "Home"){ ?>
    <option selected="selected" value="Home">Home</option>
    <?php }
    else { ?>
    <option value="Home">Home</option>
    <?php }
	  if ($type == "Work"){ ?>
    <option selected="selected" value="Work">Work</option>
    <?php }
    else { ?>
    <option value="Work">Work</option>
    <?php }
	  if ($type == "Other"){ ?>
    <option selected="selected" value="Other">Other</option>
    <?php }
    else { ?>
    <option value="Other">Other</option>
    <?php } ?>
  </select>
  <hr />
  <label for='txtAd1'>Address Line 1:</label>
  <input type="text" id="txtAd1" name='txtAd1' value="<?php echo $l1; ?>">
  <br />
  <label for='txtAd2'>Address Line 2:</label>
  <input type="text" id="txtAd2" name='txtAd2' value="<?php echo $l2; ?>">
  <br />
  <label for='txtAd3'>Address Line 3:</label>
  <input type="text" id="txtAd3" name='txtAd3' value="<?php echo $l3; ?>">
  <br />
  <label for='txtCity'>City:</label>
  <input type="text" id="txtCity" name='txtCity' value="<?php echo $city; ?>">
  <br />
  <label for='txtProv'>Province:</label>
  <input type="text" id="txtProv" name='txtProv' value="<?php echo $prov; ?>">
  <br />
  <label for='txtPostal'>Postal Code:</label>
  <input type="text" id="txtPostal" name='txtPostal' value="<?php echo $pc; ?>">
  <br />
  <label for='txtCountry'>Country:</label>
  <input type="text" id="txtCountry" name='txtCountry' value="<?php echo $cou; ?>">
  <hr />
  <?php    }
  }
  else {
    echo "<p>Error in EDIT Address table execute ".$stmt->errorCode()."</p>\n<p>Message ".implode($stmt->errorInfo())."</p>\n";
    exit(1);
  }
  $db_conn = NULL;
   //open connection to the database
   $db_conn = connectDB();
   //get PHONE info from db
   $qry = "SELECT ph_type, ph_number FROM contact_phone WHERE ph_ct_id = '$ct_id'";
   $stmt = $db_conn->prepare($qry);
   if (!$stmt) {
     echo "<p>Error in EDIT Phone table prepare: ".$dbc->errorCode()."</p>\n<p>Message ".implode($dbc->errorInfo())."</p>\n";
     exit(1);
   }
   $status = $stmt->execute();
   if ($status) {
     if ($stmt->rowCount() > 0) {
       $row = $stmt->fetch(PDO::FETCH_ASSOC);
       //variables for data from db
       $type = $row['ph_type'];
       $num = $row['ph_number'];
       ?>
  <label for='selPhType'>Phone Number Type:</label>
  <select id='selPhType' name='editPhType'>
    <?php if((strlen($type) == 0)){ ?>
    <option selected="selected" value="Choice">Select type</option>
    <?php }
    else { ?>
    <option value="Choice">Select type</option>
    <?php }
     if ($type == "Home"){ ?>
    <option selected="selected" value="Home">Home</option>
    <?php }
    else { ?>
    <option value="Home">Home</option>
    <?php }
     if ($type == "Work"){ ?>
    <option selected="selected" value="Work">Work</option>
    <?php }
    else { ?>
    <option value="Work">Work</option>
    <?php }
     if ($type == "Mobile"){ ?>
    <option selected="selected" value="Work">Mobile</option>
    <?php }
    else { ?>
    <option value="Mobile">Mobile</option>
    <?php }
     if ($type == "Fax"){ ?>
    <option selected="selected" value="Fax">Fax</option>
    <?php }
    else { ?>
    <option value="Fax">Fax</option>
    <?php }
     if ($type == "Other"){ ?>
    <option selected="selected" value="Other">Other</option>
    <?php }
    else { ?>
    <option value="Other">Other</option>
    <?php } ?>
  </select>
  <br />
  <label for='txtPhNum'>Phone Number:</label>
  <input type="tel" id="txtPhNum" name='txtPhNum' value="<?php echo $num; ?>">
  <hr />
  <?php    }
  }
  else {
    echo "<p>Error in EDIT PHONE table execute ".$stmt->errorCode()."</p>\n<p>Message ".implode($stmt->errorInfo())."</p>\n";
    exit(1);
  }
  $db_conn = NULL;
   //open connection to the database
   $db_conn = connectDB();
   //get email info from database
   $qry = "SELECT em_type, em_email FROM contact_email WHERE em_ct_id = '$ct_id'";
   $stmt = $db_conn->prepare($qry);
   if (!$stmt) {
     echo "<p>Error in EDIT Email table prepare: ".$dbc->errorCode()."</p>\n<p>Message ".implode($dbc->errorInfo())."</p>\n";
     exit(1);
   }
   $status = $stmt->execute();
   if ($status) {
     if ($stmt->rowCount() > 0) {
       $row = $stmt->fetch(PDO::FETCH_ASSOC);
       //variables for data from db
       $type = $row['em_type'];
       $email = $row['em_email'];
       ?>
  <label for='selEmType'>Email Type:</label>
  <select id='selEmType' name='editEmType'>
    <?php if((strlen($type) == 0)){ ?>
    <option selected="selected" value="Choice">Select type</option>
    <?php }
    else { ?>
    <option value="Choice">Select type</option>
    <?php }
    if ($type == "Home"){ ?>
    <option selected="selected" value="Home">Home</option>
    <?php }
    else { ?>
    <option value="Home">Home</option>
    <?php }
    if ($type == "Work"){ ?>
    <option selected="selected" value="Work">Work</option>
    <?php }
    else { ?>
    <option value="Work">Work</option>
    <?php }
    if ($type == "Other"){ ?>
    <option selected="selected" value="Other">Other</option>
    <?php }
    else { ?>
    <option value="Other">Other</option>
    <?php } ?>
  </select>
  <br />
  <label for='txtEmail'>Email Address:</label>
  <input type="email" id="txtEmail" name='txtEmail' value="<?php echo $email; ?>">
  <hr />
  <?php    }
   }
   else {
     echo "<p>Error in EDIT Email table execute ".$stmt->errorCode()."</p>\n<p>Message ".implode($stmt->errorInfo())."</p>\n";
     exit(1);
   }
   $db_conn = NULL;
   //open connection to the database
   $db_conn = connectDB();
   //get website info from database
   $qry = "SELECT we_type, we_url FROM contact_web WHERE we_ct_id = '$ct_id'";
   $stmt = $db_conn->prepare($qry);
   if (!$stmt) {
     echo "<p>Error in EDIT Web table prepare: ".$dbc->errorCode()."</p>\n<p>Message ".implode($dbc->errorInfo())."</p>\n";
     exit(1);
   }
   $status = $stmt->execute();
   if ($status) {
     if ($stmt->rowCount() > 0) {
       $row = $stmt->fetch(PDO::FETCH_ASSOC);
       //variables for data from db
       $type = $row['we_type'];
       $url = $row['we_url'];
       ?>
  <label for='selWebType'>Website Type:</label>
  <select id='selWebType' name='editWebType'>
    <?php if((strlen($type) == 0)){ ?>
    <option selected="selected" value="Choice">Select type</option>
    <?php }
    else { ?>
    <option value="Choice">Select type</option>
    <?php }
    if ($type == "Personal"){ ?>
    <option selected="selected" value="Personal">Personal</option>
    <?php }
    else { ?>
    <option value="Personal">Personal</option>
    <?php }
    if ($type == "Work"){ ?>
    <option selected="selected" value="Work">Work</option>
    <?php }
    else { ?>
    <option value="Work">Work</option>
    <?php }
    if ($type == "Linked In"){ ?>
    <option selected="selected" value="LinkedIn">LinkedIn</option>
    <?php }
    else { ?>
    <option value="Linked In">LinkedIn</option>
    <?php }
    if ($type == "Facebook"){ ?>
    <option selected="selected" value="Facebook">Facebook</option>
    <?php }
    else { ?>
    <option value="Facebook">Facebook</option>
    <?php }
    if ($type == "Other"){ ?>
    <option selected="selected" value="Other">Other</option>
    <?php }
    else { ?>
    <option value="Other">Other</option>
    <?php } ?>
  </select>
  <br />
  <label for='txtWebURL'>URL:</label>
  <input type="url" id="txtWebURL" name='txtWebURL' value="<?php echo $url; ?>">
  <hr />
  <?php    }
   }
   else {
     echo "<p>Error in EDIT Web table execute ".$stmt->errorCode()."</p>\n<p>Message ".implode($stmt->errorInfo())."</p>\n";
     exit(1);
   }
   $db_conn = NULL;
   //open connection to the database
   $db_conn = connectDB();
   //get note info from database
   $qry = "SELECT no_note FROM contact_note WHERE no_ct_id = '$ct_id'";
   $stmt = $db_conn->prepare($qry);
   if (!$stmt) {
     echo "<p>Error in EDIT NOTE table prepare: ".$dbc->errorCode()."</p>\n<p>Message ".implode($dbc->errorInfo())."</p>\n";
     exit(1);
   }
   $status = $stmt->execute();
   if ($status) {
     if ($stmt->rowCount() > 0) {
       $row = $stmt->fetch(PDO::FETCH_ASSOC);
       //variables for data from the db
       $note = $row['no_note'];
       ?>
  <label for='txtNote'>Note:</label>
  <textarea id="txtNote" name='txtEditNote' maxlength="65530"><?php echo $note ?></textarea>
  <hr />
  <?php }
   }
   else {
     echo "<p>Error in EDIT NOTE table execute ".$stmt->errorCode()."</p>\n<p>Message ".implode($stmt->errorInfo())."</p>\n";
     exit(1);
   } ?>
  <input type='submit' id='btnCancel' name='btnCancelEdit' value='Cancel' />
  <input type='submit' id='btnSaveEdit' name='btnSaveEdit' value='Save' />
</form>
<?php } ?>
<?php function validateEdits() {
  $err_msgs = array();
	if (!isset($_POST['editSelType'])){
		$err_msgs[] = "Please select a contact type";
	}
  else {
		$ct_type = trim($_POST['editSelType']);
		if (!(($ct_type == "Friend") || ($ct_type == "Family") || ($ct_type == "Business") || ($ct_type == "Other"))){
			$err_msgs[] = "Please select a contact type";
		}
	}
	if (count($err_msgs) == 0){
		$_POST['ct_type'] = $ct_type;
  }
  if (!isset($_POST['editAdType'])){
		$err_msgs[] = "Please select an address type";
	}
  else if (isset($_POST['editAdType'])){
		$type = trim($_POST['editAdType']);
		if (!(($type == "Home") || ($type == "Work") || ($type == "Other"))){
			$err_msgs[] = "Please select an email address type";
		}
	}
	if(!isset($_POST['txtAd1'])){
		$err_msgs[] = "Please enter a first address";
	}
  else {
		$line1 = trim($_POST['txtAd1']);
		if (strlen($line1) == 0){
			$err_msgs[] = "Please enter a first address";
		}
    else if (strlen($line1) > 100){
			$err_msgs[] = "First address too long";
		}
	}
	if(isset($_POST['txtAd2'])){
		$line2 = trim($_POST['txtAd2']);
		if (strlen($line2) > 100){
			$err_msgs[] = "Second address too long";
		}
	}
	if(isset($_POST['txtAd3'])){
		$line3 = trim($_POST['txtAd3']);
		if (strlen($line3) > 100){
			$err_msgs[] = "Third address too long";
		}
	}
	if(!isset($_POST['txtCity'])){
		$err_msgs[] = "Please enter a city";
	}
  else {
		$city = trim($_POST['txtCity']);
		if (strlen($city) == 0){
			$err_msgs[] = "Please enter a city";
		}
    else if (strlen($city) > 50){
			$err_msgs[] = "City is too long";
		}
	}
	if(isset($_POST['txtProv'])){
		$prov = trim($_POST['txtProv']);
		if (strlen($prov) > 50){
			$err_msgs[] = "Province is too long";
		}
	}
	if(isset($_POST['txtPostal'])){
		$post = trim($_POST['txtPostal']);
		if (strlen($post) > 15){
			$err_msgs[] = "Postal Code is too long";
		}
	}
	if(isset($_POST['txtCountry'])){
		$country = trim($_POST['txtCountry']);
		if (strlen($country) > 50){
			$err_msgs[] = "Country is too long";
		}
  }
  if(!isset($_POST['txtPhNum'])){
		$err_msgs[] = "Please enter a phone number";
	}
  else {
		$number = trim($_POST['txtPhNum']);
		if (strlen($number) == 0){
			$err_msgs[] = "Please enter a phone number";
		}
    else if (strlen($number) > 50){
			$err_msgs[] = "The phone number is too long";
		}
    else {
      $regexbracket = "/^[(][\d]{3}[)][\d]{3}[-][\d]{4}$/";
		  $regexnobracket = "/^[\d]{3}[-][\d]{3}[-][\d]{4}$/";
      $regexbracketwithavalue = "/^[+1]{2}[(][\d]{3}[)][\d]{3}[-][\d]{4}$/";
      if (!((preg_match($regexbracket,$number) || (preg_match($regexnobracket,$number)) || (preg_match($regexbracketwithavalue,$number))))) {
        $err_msgs[] = 'Phone number is formatted incorrectly';
      }
    }
  }
	if (!isset($_POST['editEmType'])){
		$err_msgs[] = "Please choose an email type";
	}
  else if (isset($_POST['editEmType'])){
		$type = trim($_POST['editEmType']);
		if (!(($type == "Home") || ($type == "Work")
				|| ($type == "Other"))){
			$err_msgs[] = "Please choose an email type";
		}
	}
	if(!isset($_POST['txtEmail'])){
		$err_msgs[] = "Please enter an email";
	}
  else {
		$email = trim($_POST['txtEmail']);
		if (strlen($email) == 0){
			$err_msgs[] = "Please enter an email";
		}
    else if (strlen($email) > 50){
			$err_msgs[] = "The email address is too long";
		}
    else {
      $regex = "/^[a-zA-z\d\._]+@[a-zA-z\d\._]+\.[a-zA-z\d\.]{2,}+$/";
      if(!(preg_match($regex,$email))) {
        $err_msgs[] = 'Invalid email';
      }
    }
  }
  if (!isset($_POST['editWebType'])){
		$err_msgs[] = "Please select a website";
	}
  else if (isset($_POST['editWebType'])){
		$type = trim($_POST['editWebType']);
		if (!(($type == "Personal") || ($type == "Work")
				|| ($type == "Linked In")
				|| ($type == "Facebook")|| ($type == "Other"))){
			$err_msgs[] = "Please select a website";
		}
	}
	if(!isset($_POST['txtWebURL'])){
		$err_msgs[] = "Please enter a URL";
	}
  else {
		$url = trim($_POST['txtWebURL']);
		if (strlen($url) == 0){
			$err_msgs[] = "Please enter a URL";
		}
    else if (strlen($url) > 255){
			$err_msgs[] = "The URL is too long";
		}
	}
	if (count($err_msgs) == 0){
		$_POST['we_type'] = $type;
    $_POST['we_url'] = $url;
    $_POST['ad_type'] = $type;
		$_POST['ad_line_1'] = $line1;
		$_POST['ad_city'] = $city;
	}
	return $err_msgs;
} ?>
